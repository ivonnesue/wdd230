#  WDD: JavaScript - Formatted Current Date

A Pen created on CodePen.io. Original URL: [https://codepen.io/blazzard-jason/pen/JNzKpY](https://codepen.io/blazzard-jason/pen/JNzKpY).

